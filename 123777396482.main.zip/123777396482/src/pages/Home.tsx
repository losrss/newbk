import { useState, useEffect } from 'react';
import axios from 'axios';

// 博客数据类型定义
interface Blog {
  id: number;
  name: string;
  description: string;
  author: string;
  author_id: string;
  join_time: string;
  uv: number;
  rv: number;
  last_link_time: string;
  last_visit_time: string;
  status: 'active' | 'pending_removal';
}

export default function Home() {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [filteredBlogs, setFilteredBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // 获取博客数据
  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        // 使用模拟数据，实际项目中应替换为真实API调用
        const mockBlogs: Blog[] = [
          {
            id: 1,
            name: "技术沉思录",
            description: "分享编程技术与开发经验，专注前端与Node.js领域",
            author: "王技术",
            author_id: "tech_wang",
            join_time: "2023-05-15",
            uv: 12500,
            rv: 18700,
            last_link_time: "2024-03-20",
            last_visit_time: "2024-03-21",
            status: "active"
          },
          {
            id: 2,
            name: "设计笔记",
            description: "UI/UX设计经验分享，设计工具与趋势分析",
            author: "李设计",
            author_id: "design_li",
            join_time: "2023-07-22",
            uv: 9800,
            rv: 14500,
            last_link_time: "2024-03-18",
            last_visit_time: "2024-03-19",
            status: "active"
          },
          {
            id: 3,
            name: "产品思维",
            description: "产品经理的日常思考与经验总结",
            author: "张产品",
            author_id: "pm_zhang",
            join_time: "2023-09-10",
            uv: 8700,
            rv: 12300,
            last_link_time: "2024-03-15",
            last_visit_time: "2024-03-16",
            status: "active"
          },
          {
            id: 4,
            name: "数据科学",
            description: "数据分析、机器学习与人工智能实践",
            author: "赵数据",
            author_id: "data_zhao",
            join_time: "2023-11-05",
            uv: 7500,
            rv: 11200,
            last_link_time: "2024-03-12",
            last_visit_time: "2024-03-13",
            status: "active"
          },
          {
            id: 5,
            name: "创业日记",
            description: "记录创业过程中的点滴与思考",
            author: "钱创业",
            author_id: "startup_qian",
            join_time: "2023-12-18",
            uv: 6800,
            rv: 9800,
            last_link_time: "2024-03-10",
            last_visit_time: "2024-03-11",
            status: "active"
          },
          {
            id: 6,
            name: "旧时光",
            description: "个人生活随笔与读书笔记",
            author: "孙时光",
            author_id: "time_sun",
            join_time: "2023-02-28",
            uv: 3200,
            rv: 4500,
            last_link_time: "2023-12-25",
            last_visit_time: "2023-12-26",
            status: "pending_removal"
          },
          {
            id: 7,
            name: "旅行见闻",
            description: "记录世界各地的旅行见闻与攻略",
            author: "周旅行",
            author_id: "travel_zhou",
            join_time: "2023-04-10",
            uv: 2800,
            rv: 3900,
            last_link_time: "2023-11-15",
            last_visit_time: "2023-11-16",
            status: "pending_removal"
          }
        ];
        
        setBlogs(mockBlogs);
        setFilteredBlogs(mockBlogs);
        setLoading(false);
      } catch (err) {
        setError('获取博客数据失败，请稍后重试');
        setLoading(false);
        console.error('Error fetching blogs:', err);
      }
    };

    fetchBlogs();
  }, []);

  // 搜索功能
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const searchTerm = e.target.value.toLowerCase();
    
    if (searchTerm.trim() === '') {
      setFilteredBlogs(blogs);
      return;
    }

    const results = blogs.filter(blog => 
      blog.name.toLowerCase().includes(searchTerm) || 
      blog.author.toLowerCase().includes(searchTerm) || 
      blog.description.toLowerCase().includes(searchTerm)
    );

    setFilteredBlogs(results);
  };

  // 排序功能
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  // 获取排序后的博客列表
  const getSortedBlogs = () => {
    if (!sortColumn) return filteredBlogs;
    
    return [...filteredBlogs].sort((a, b) => {
      if (a[sortColumn as keyof Blog] < b[sortColumn as keyof Blog]) {
        return sortDirection === 'asc' ? -1 : 1;
      }
      if (a[sortColumn as keyof Blog] > b[sortColumn as keyof Blog]) {
        return sortDirection === 'asc' ? 1 : -1;
      }
      return 0;
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500 mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">加载博客数据中...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center">
          <p className="text-red-600 dark:text-red-400 mb-4">{error}</p>
          <button 
            onClick={() => window.location.reload()}
            className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-md"
          >
            重试
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* 顶部标题区 */}
      <header className="bg-white dark:bg-gray-800 py-8 px-4 shadow-sm">
        <div className="container mx-auto max-w-6xl">
          <h1 className="text-3xl md:text-4xl font-bold text-center mb-2 text-gray-900 dark:text-white">博客聚合平台</h1>
          <p className="text-gray-600 dark:text-gray-300 text-center max-w-2xl mx-auto">发现并分享优质个人博客站点</p>
        </div>
      </header>

      {/* 搜索栏 */}
      <div className="bg-white dark:bg-gray-800 py-4 px-4 shadow-sm sticky top-0 z-10">
        <div className="container mx-auto max-w-6xl">
          <div className="relative">
            <input 
              type="text" 
              placeholder="搜索博客名称、作者或关键词..." 
              className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              onChange={handleSearch}
            />
            <i className="fas fa-search absolute right-3 top-3 text-gray-400"></i>
          </div>
        </div>
      </div>

      {/* 主要内容区 */}
      <main className="container mx-auto max-w-6xl py-8 px-4">
        {/* 博客卡片列表区 */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-6 flex items-center text-gray-900 dark:text-white">
            <i className="fas fa-blog mr-2 text-blue-500"></i>博客列表
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="blogCards">
            {filteredBlogs.filter(blog => blog.status === 'active').map(blog => (
              <div key={blog.id} className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 card-hover transition-all duration-200 hover:shadow-md hover:-translate-y-1">
                <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-white">{blog.name}</h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">{blog.description}</p>
                <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                  <i className="fas fa-user mr-2"></i>
                  <span>{blog.author}</span>
                  <span className="mx-2">•</span>
                  <i className="fas fa-calendar-alt mr-2"></i>
                  <span>加入于 {blog.join_time}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* 30天排行表格区 */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold mb-6 flex items-center text-gray-900 dark:text-white">
            <i className="fas fa-chart-line mr-2 text-blue-500"></i>30天排行
          </h2>
          <div className="overflow-x-auto bg-white dark:bg-gray-800 rounded-lg shadow-sm">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('name')}
                  >
                    博客名称 
                    {sortColumn === 'name' && (
                      <i className={`fas ml-1 ${sortDirection === 'asc' ? 'fa-sort-up' : 'fa-sort-down'}`}></i>
                    )}
                    {sortColumn !== 'name' && (
                      <i className="fas fa-sort ml-1"></i>
                    )}
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('uv')}
                  >
                    UV 
                    {sortColumn === 'uv' && (
                      <i className={`fas ml-1 ${sortDirection === 'asc' ? 'fa-sort-up' : 'fa-sort-down'}`}></i>
                    )}
                    {sortColumn !== 'uv' && (
                      <i className="fas fa-sort ml-1"></i>
                    )}
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('rv')}
                  >
                    RV 
                    {sortColumn === 'rv' && (
                      <i className={`fas ml-1 ${sortDirection === 'asc' ? 'fa-sort-up' : 'fa-sort-down'}`}></i>
                    )}
                    {sortColumn !== 'rv' && (
                      <i className="fas fa-sort ml-1"></i>
                    )}
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('last_link_time')}
                  >
                    最后链入 
                    {sortColumn === 'last_link_time' && (
                      <i className={`fas ml-1 ${sortDirection === 'asc' ? 'fa-sort-up' : 'fa-sort-down'}`}></i>
                    )}
                    {sortColumn !== 'last_link_time' && (
                      <i className="fas fa-sort ml-1"></i>
                    )}
                  </th>
                  <th 
                    scope="col" 
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider cursor-pointer"
                    onClick={() => handleSort('last_visit_time')}
                  >
                    最后受访 
                    {sortColumn === 'last_visit_time' && (
                      <i className={`fas ml-1 ${sortDirection === 'asc' ? 'fa-sort-up' : 'fa-sort-down'}`}></i>
                    )}
                    {sortColumn !== 'last_visit_time' && (
                      <i className="fas fa-sort ml-1"></i>
                    )}
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                {getSortedBlogs().filter(blog => blog.status === 'active').map(blog => (
                  <tr key={blog.id} className="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium text-gray-900 dark:text-white">{blog.name}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">{blog.author}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-gray-900 dark:text-white">{blog.uv.toLocaleString()}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-gray-900 dark:text-white">{blog.rv.toLocaleString()}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-gray-900 dark:text-white">{blog.last_link_time}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-gray-900 dark:text-white">{blog.last_visit_time}</div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* 即将移除表格区 */}
        <section>
          <h2 className="text-2xl font-semibold mb-6 flex items-center text-gray-900 dark:text-white">
            <i className="fas fa-exclamation-triangle mr-2 text-yellow-500"></i>即将移除
          </h2>
          <div className="overflow-x-auto bg-white dark:bg-gray-800 rounded-lg shadow-sm">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    博客名称
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    加入时间
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    最后活动
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                    状态
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                {blogs.filter(blog => blog.status === 'pending_removal').map(blog => (
                  <tr key={blog.id} className="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium text-gray-900 dark:text-white">{blog.name}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">{blog.author}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-gray-900 dark:text-white">{blog.join_time}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-gray-900 dark:text-white">{blog.last_visit_time}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300">
                        即将移除
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>

      {/* 页脚 */}
      <footer className="bg-white dark:bg-gray-800 py-8 px-4 border-t border-gray-200 dark:border-gray-700 mt-12">
        <div className="container mx-auto max-w-6xl text-center text-gray-500 dark:text-gray-400 text-sm">
          <p>© 2024 博客聚合平台. 保留所有权利.</p>
          <p className="mt-2">
            <span>created by </span>
            <a href="/admin" className="text-blue-600 dark:text-blue-400 hover:underline">管理后台</a>
          </p>
        </div>
      </footer>
    </div>
  );
}