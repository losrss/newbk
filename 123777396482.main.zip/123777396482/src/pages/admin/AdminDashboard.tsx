import { useState, useEffect, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '@/contexts/authContext';
import { toast } from 'sonner';

// 博客数据类型定义
interface Blog {
  id: number;
  name: string;
  description: string;
  author: string;
  author_id: string;
  join_time: string;
  uv: number;
  rv: number;
  last_link_time: string;
  last_visit_time: string;
  status: 'active' | 'pending_removal';
}

// 博客表单数据类型
interface BlogFormData {
  name: string;
  description: string;
  author: string;
  author_id: string;
}

export default function AdminDashboard() {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [currentBlog, setCurrentBlog] = useState<Blog | null>(null);
  const [formData, setFormData] = useState<BlogFormData>({
    name: '',
    description: '',
    author: '',
    author_id: ''
  });
  
  const { logout } = useContext(AuthContext);
  const navigate = useNavigate();

  // 获取博客列表
  const fetchBlogs = async () => {
    try {
      setLoading(true);
      
      // 使用模拟数据，实际项目中应替换为真实API调用
      const mockBlogs: Blog[] = [
        {
          id: 1,
          name: "技术沉思录",
          description: "分享编程技术与开发经验，专注前端与Node.js领域",
          author: "王技术",
          author_id: "tech_wang",
          join_time: "2023-05-15",
          uv: 12500,
          rv: 18700,
          last_link_time: "2024-03-20",
          last_visit_time: "2024-03-21",
          status: "active"
        },
        {
          id: 2,
          name: "设计笔记",
          description: "UI/UX设计经验分享，设计工具与趋势分析",
          author: "李设计",
          author_id: "design_li",
          join_time: "2023-07-22",
          uv: 9800,
          rv: 14500,
          last_link_time: "2024-03-18",
          last_visit_time: "2024-03-19",
          status: "active"
        },
        {
          id: 3,
          name: "产品思维",
          description: "产品经理的日常思考与经验总结",
          author: "张产品",
          author_id: "pm_zhang",
          join_time: "202３-09-10",
          uv: 8700,
          rv: 12300,
          last_link_time: "2024-03-15",
          last_visit_time: "2024-03-16",
          status: "active"
        }
      ];
      
      setBlogs(mockBlogs);
      setError(null);
    } catch (err) {
      setError('获取博客列表失败');
      console.error('Error fetching blogs:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBlogs();
  }, []);

  // 处理表单变化
  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // 打开添加博客模态框
  const openAddModal = () => {
    setCurrentBlog(null);
    setFormData({
      name: '',
      description: '',
      author: '',
      author_id: ''
    });
    setIsAddModalOpen(true);
  };

  // 打开编辑博客模态框
  const openEditModal = (blog: Blog) => {
    setCurrentBlog(blog);
    setFormData({
      name: blog.name,
      description: blog.description,
      author: blog.author,
      author_id: blog.author_id
    });
    setIsAddModalOpen(true);
  };

  // 关闭模态框
  const closeModal = () => {
    setIsAddModalOpen(false);
  };

  // 提交博客表单
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // 简单验证
    if (!formData.name || !formData.author) {
      toast.error('博客名称和作者不能为空');
      return;
    }
    
    try {
      // 模拟API调用
      if (currentBlog) {
        // 编辑博客
        const updatedBlogs = blogs.map(blog => 
          blog.id === currentBlog.id ? { ...blog, ...formData } : blog
        );
        setBlogs(updatedBlogs);
        toast.success('博客更新成功');
      } else {
        // 添加新博客
        const newBlog: Blog = {
          id: blogs.length + 1,
          ...formData,
          join_time: new Date().toISOString().split('T')[0],
          uv: 0,
          rv: 0,
          last_link_time: new Date().toISOString().split('T')[0],
          last_visit_time: new Date().toISOString().split('T')[0],
          status: 'active'
        };
        
        setBlogs([...blogs, newBlog]);
        toast.success('博客添加成功');
      }
      
      closeModal();
    } catch (err) {
      toast.error(currentBlog ? '博客更新失败' : '博客添加失败');
      console.error('Error saving blog:', err);
    }
  };

  // 删除博客
  const handleDelete = async (id: number) => {
    if (window.confirm('确定要删除这个博客吗？')) {
      try {
        // 模拟API调用
        setBlogs(blogs.filter(blog => blog.id !== id));
        toast.success('博客删除成功');
      } catch (err) {
        toast.error('博客删除失败');
        console.error('Error deleting blog:', err);
      }
    }
  };

  // 更改博客状态
  const handleStatusChange = async (id: number, newStatus: 'active' | 'pending_removal') => {
    try {
      // 模拟API调用
      const updatedBlogs = blogs.map(blog => 
        blog.id === id ? { ...blog, status: newStatus } : blog
      );
      setBlogs(updatedBlogs);
      toast.success(`博客状态已更新为${newStatus === 'active' ? '活跃' : '即将移除'}`);
    } catch (err) {
      toast.error('更新状态失败');
      console.error('Error updating status:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col">
      {/* 顶部导航栏 */}
      <header className="bg-white dark:bg-gray-800 shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">博客管理后台</h1>
            </div>
            <div className="flex items-center">
              <button
                onClick={logout}
                className="bg-red-500 hover:bg-red-600 text-white py-2 px-4 rounded-md"
              >
                <i className="fas fa-sign-out-alt mr-1"></i> 退出登录
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* 主要内容区 */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-white">博客管理</h2>
          <button
            onClick={openAddModal}
            className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-md"
          >
            <i className="fas fa-plus mr-1"></i> 添加博客
          </button>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : error ? (
          <div className="bg-red-100 dark:bg-red-900 border border-red-400 text-red-700 dark:text-red-300 px-4 py-3 rounded relative" role="alert">
            <span className="block sm:inline">{error}</span>
            <button 
              onClick={fetchBlogs}
              className="absolute top-0 bottom-0 right-0 px-4 py-3 text-red-700 dark:text-red-300 hover:bg-red-200 dark:hover:bg-red-800"
            >
              <i className="fas fa-sync-alt"></i>
            </button>
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 overflow-hidden shadow rounded-lg">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-700">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">ID</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">博客名称</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">作者</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">加入时间</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">状态</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">操作</th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {blogs.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-10 text-center text-gray-500 dark:text-gray-400">
                        暂无博客数据，请添加博客
                      </td>
                    </tr>
                  ) : (
                    blogs.map((blog) => (
                      <tr key={blog.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{blog.id}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900 dark:text-white">{blog.name}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400 truncate max-w-xs">{blog.description}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{blog.author}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{blog.join_time}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            blog.status === 'active' 
                              ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' 
                              : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
                          }`}>
                            {blog.status === 'active' ? '活跃' : '即将移除'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <button
                            onClick={() => openEditModal(blog)}
                            className="text-blue-600 dark:text-blue-400 hover:text-blue-900 dark:hover:text-blue-300 mr-4"
                          >
                            <i className="fas fa-edit"></i> 编辑
                          </button>
                          <button
                            onClick={() => handleStatusChange(blog.id, blog.status === 'active' ? 'pending_removal' : 'active')}
                            className={`${
                              blog.status === 'active' 
                                ? 'text-yellow-600 dark:text-yellow-400 hover:text-yellow-900 dark:hover:text-yellow-300 mr-4' 
                                : 'text-green-600 dark:text-green-400 hover:text-green-900 dark:hover:text-green-300 mr-4'
                            }`}
                          >
                            <i className={`fas ${blog.status === 'active' ? 'fa-pause-circle' : 'fa-play-circle'}`}></i> {blog.status === 'active' ? '暂停' : '激活'}
                          </button>
                          <button
                            onClick={() => handleDelete(blog.id)}
                            className="text-red-600 dark:text-red-400 hover:text-red-900 dark:hover:text-red-300"
                          >
                            <i className="fas fa-trash"></i> 删除
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* 添加/编辑博客模态框 */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                {currentBlog ? '编辑博客' : '添加新博客'}
              </h3>
              <button
                onClick={closeModal}
                className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6">
              <div className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    博客名称 <span className="text-red-500">*</span>
                  </label>
                  <input 
                    type="text" 
                    id="name" 
                    name="name" 
                    value={formData.name}
                    onChange={handleFormChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  />
                </div>
                
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    博客描述
                  </label>
                  <textarea 
                    id="description" 
                    name="description" 
                    rows={3}
                    value={formData.description}
                    onChange={handleFormChange}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-.500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  ></textarea>
                </div>
                
                <div>
                  <label htmlFor="author" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    作者 <span className="text-red-500">*</span>
                  </label>
                  <input 
                    type="text" 
                    id="author" 
                    name="author" 
                    value={formData.author}
                    onChange={handleFormChange}
                    required
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  />
                </div>
                
                <div>
                  <label htmlFor="author_id" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    作者ID
                  </label>
                  <input 
                    type="text" 
                    id="author_id" 
                    name="author_id" 
                    value={formData.author_id}
                    onChange={handleFormChange}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  />
                </div>
              </div>
              
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={closeModal}
                  className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
                >
                  {currentBlog ? '更新博客' : '添加博客'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}